# 新⽯器⽆⼈⻋接⼝⽂档 （2025.05）

# 1 请求说明

# 1.1、请求地址:

测试环境https://scapi.test.neolix.net/

线上环境https://scapi.neolix.net/

测试账号信息: client_id: zlt, client_secret:zlt

# 1.2、⾃定义http协议头

# 1.2.1、X-From

为了⽅便管理，业务⽅需要在每个http请求中增加⾃定义协议头X-From，并且保持唯⼀

# 1.2.2、X-Version

为了区分业务⽅的版本号，⽅便⽇后的限流与灰度，格式A.B.C, 默认值是0.0.0

# 1.3、Token⽣成规则

1.测试联调完成之后，联系产品经理申请线上账号  
2.接⼝响应坐标均为gcj02坐标系   
3.获取token⽰例:

https://scapi.test.neolix.net/auth/oauth/token? grant_type=client_credentials&client_id $\mathbf { \equiv } _ { - }$ zlt&client_secret=zlt

签名⽣成规则:

# 代码块

1 /\*\*  
2 $\star$ 生成签名  
3 $\star$ 4 $\star$ @param timestamp秒级时间戳  
5 $\star$ @param nonce 两位随机整数  
6 $\star$ @param appSecret即client_secret  
7 $\star$ @return  
8 $\star /$ 9 public static String getSignature(String timestamp, String nonce, String appSecret）{

```java
//对token,timestamp nonce 按字典排序
String[] paramArr = new String[]{appSecret, timestamp, nonce};
Arrays.sort(paramArr);
//将排序后的结果拼接成一个字符串
String content = paramArr[0].concat(paramArr[1]).concat(paramArr[2]);
String ciphertext = null;
try {
    MessageDigest md = MessageDigest.getInstance("SHA-1");
    //对拼接后的字符串进行sha1加密 update// 使用指定的字节数组对摘要进行最后更新
    byte[] digest = md.digest(content.toString().getBytes());
    //完成摘要计算
    ciphertext = byteToStringdigest);
} catch (Exception e) {
    e.printStackTrace();
}
//将sha1加密后的字符串与signature进行对比
return ciphertext;
}
/**
* 字节转成字符串
*/
* @param digest
* @return */
*/
public static String byteToString(byte[] digest) {
    try {
        StringBuffer hexString = new StringBuffer();
        // 字节数组转换为十六进制数
        for (int i = 0; i < digest.length; i++) {
            String shaHex = Integer.toString(digest[i] & 0xFF);
            if (shaHex.length() < 2) {
                hexString.append(0);
            }
            hexString.append(shaHex);
        }
        return hexString.toString();
} catch (Exception e) {
    e.printStackTrace();
} 
```

# 2 getAccessToken

GET /auth/oauth/token

# 接⼝说明

获取token

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>client_id</td><td></td><td>Application ID</td></tr><tr><td>client_secret</td><td></td><td>Application secret</td></tr><tr><td>grant_type</td><td></td><td>client_creditsals</td></tr></table>

# 响应体

代码块

```json
1 {   
2 "access_token": "0bd78f5f-bdd3-4f83-895d-dbaa5ffd302d", --返回的用户调用凭证   
3 "token_type": "bearer",   
4 "Expires_in": 79999, --过期时间 过期时间单位为S   
5 "scope": "all"   
6 }
```

# 3 getVehicleList

GET /openapi-server/slvapi/getVehicleList

# 接⼝说明

获取⽤⼾拥有的⻋辆列表

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr><tr><td>userId</td><td></td><td>用户id</td></tr></table>

# 响应体

代码块

```txt
1 {  
2 "data": [  
3 {  
4 "vin": "LHT4A2A18KC93A002",  
5 "vinId": "C84",  
6 "vinCode": "测试车辆001" //车牌号  
7 "parkCode":"01065" ----网格编号  
8 "parkName":"工厂" ----网格名称  
9 "cabinCode":"""  
10 }  
11 ],  
12 "code": "10000",  
13 "msg": "成功",  
14 "success": true  
15 } 
```

# 4 getVehicleInfo

POST /openapi-server/slvapi/getVehicleInfo

# 接⼝说明

获取⻋辆状态信息

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>built by timestamp+nonce+)appSecr</td></tr><tr><td rowspan="2">timeStamp</td><td>1723</td><td>et</td></tr><tr><td>1723</td><td>current timestamp</td></tr><tr><td>nonce</td><td>1723</td><td>number once</td></tr><tr><td>vin</td><td>1723</td><td>vehicle VIN</td></tr><tr><td>access_token</td><td>1723</td><td>accessToken grasped by / OAuth-token API</td></tr></table>

# 响应体

代码块  
```jsonl
1 {   
2 "data":{   
3 {   
4 } "vin":"1",--vin   
5 "vinId":"1",--vinId   
6 "driveMode":1 --驾驶模式1自动驾驶模式2远程脱困模式3近场遥控模式0缺省   
7 "gear":"D" --档位   
8 "speed":0.0,--车速km/h   
9 "acceleration_V": 0.0--[0.20000]车辆行驶纵向加速度，单   
位：0.01m/s2,offset=-100,表示实   
10 际值[-100..100] 65535表示缺省   
11 "acceleration_H": 0.0--[0.20000]车辆行驶横向加速度，单   
位：0.01m/s2,offset=-100,表示实   
12 际值[-100..100] 65535表示缺省   
13 "gnssHead":1.1--航向角   
14 "position":{-位置信息   
15 "lon":116.29435747861862，--经度   
16 "lat":40.05025582727537--纬度   
17 },   
18 "electricity":100，--后舱电池电量   
19 "frontBattery" 10,-前舱电池电量   
20 "realBattery" 10,-真正的电池(即当前使用的电池电量)   
21 "mile":100.11，--续航里程 Km   
22 "occurTimestamp":1658396724538，--毫秒级时间戳，   
23 "powerState":true --是否在线   
24 "parkCode":"01065" ----网格编号   
25 "parkName":"工厂" ----网格名称   
26 },   
27 "code":"10000",   
28 "msg":"成功"   
29 }
```

# 5 listStationByVin

POST /openapi-server/slvapi/listStationByVin/v1

# 接⼝说明

获取⻋辆所属⽹点下所有停靠点

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>built by timestamp+nonce+appSecret</td></tr><tr><td>timeStamp</td><td></td><td>current timestamp</td></tr><tr><td>nonce</td><td></td><td>number once</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr><tr><td>vin</td><td></td><td>车辆vin</td></tr></table>

# 响应体

代码块

```txt
1 {   
2 "data":[   
3 {   
4 } "lng":116.4977275142568，--经度   
5 "stationName":"站点名称"，--站点名称   
6 "lat":39.97844903572148，--纬度   
7 "stationId":1，--站点id   
8 "parkCode":"011111" --网格编号   
9 "parkName":"工厂"----网格名称   
10 }   
11 ]   
12 "code":"100000"，   
13 "msg":"成功"
```

# 6 missionStart

POST /openapi-server/slvapi/vehicleStart/v1

# 接⼝说明

驱动⻋辆A->B（合作⽅结合业务系统场景多次调⽤该接⼝可实现串点任务⾏驶）

请求参数(Query Param)  

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

请求体(Request Body)   

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>&quot;123&quot;, --车辆vin</td></tr><tr><td>departureStationId</td><td>string</td><td></td><td>true</td><td>起站点id</td></tr><tr><td>destinationStationId</td><td>string</td><td></td><td>true</td><td>目的站点id</td></tr><tr><td>business</td><td>string</td><td></td><td>true</td><td>&quot;&quot;--固定值 按需分配</td></tr><tr><td>backUrl</td><td>string</td><td></td><td>false</td><td>回调url，未传则需联调先提供</td></tr></table>

# 响应体

代码块

```snap
1 {   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": {   
5 "missionId":1 --任务id   
6 }   
7 } 
```

# 7 getCurrentMission

POST /openapi-server/slvapi/getCurrentMission

# 接⼝说明

查询⻋辆当前任务详情

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td></td></tr></table>

# 响应体

代码块  
```txt
1 {   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": {   
5 "missionSubId" --任务id   
6 "vin": "vin",   
7 "startStationId": 0,   
8 "startStationName": "起点名称",   
9 "endStationId": 0,   
10 "endStationName": "终点名称"   
11 "missionStatus": 1 // 1.执行中3.已完成，4.已取消   
12 }   
13 }   
14
```

# 8 getPlanningRoute

POST /openapi-server/slvapi/getPlanningRoute

# 接⼝说明

查询⻋辆规划路线

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>vin</td></tr></table>

# 响应体

代码块  
```txt
1 {   
2 "data": [   
3 {   
4 "routeId": 11968,   
5 "route": ""   
[{{"latitude":33.345928499708485,"longitude":120.20249158143997,"订单Id": 1,"stationId":82582,"stationName":"\高精点-01"},   
{“latitude":33.325011980701625,"longitude":120.17529934644699,"订单Id":2 , "stationId":124719,"stationName":"\盐城工厂停车点-zzl-2"}]”，   
6 "routes": "路线名称",   
7 "distance":1000，--路线里程 单位米   
8 "routePath":[{"lat":11.11,"lng":11.11}] //线路路径   
9 }   
10 ],   
11 "code": "10000",   
12 "msg": "成功",   
13 "success": true   
14 } 
```

# 9 missionCancel（⻋速为0时⽅可取消）

POST /openapi-server/slvapi/vehicleCancel

# 接⼝说明

任务取消

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr><tr><td>sign_1723</td><td>sign_1723</td><td>sign_1723</td></tr></table>

# 响应体

# 代码块

{1   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": null   
}5

# 10 cabinetOpen

POST /openapi-server/slvapi/cabinetOpen

# 接⼝说明

打开货箱

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>built by timestamp+nonce+appSecret</td></tr><tr><td>timeStamp</td><td></td><td>current timestamp</td></tr><tr><td>nonce</td><td></td><td>number once</td></tr><tr><td>access_token</td><td></td><td>accessToken grasped by / OAuth-token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>&quot;123&quot;,--车辆vin</td></tr></table>

# 响应体

代码块{ 1  
2 "code": "10000",   
3 "msg": "成功",   
4 "data": null   
}5

# 11 powerOnOff

POST /openapi-server/slvapi/powerOnOff

# 接⼝说明

⻋辆开关机

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>车辆vin</td></tr><tr><td>handleType</td><td>int</td><td></td><td>true</td><td>操作类型1--上电2-下电</td></tr></table>

# 响应体

代码块

```txt
1 { "code": "10000", "msg": "成功", "data": null } 
```

# 12 switchCage

POST /vehicle-center/slvapi/switchCage

# 接⼝说明

开关笼

请求参数(Query Param)  

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

请求体(Request Body)   

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>车辆vin</td></tr><tr><td>control</td><td>int</td><td></td><td>true</td><td>1装车(关笼),2卸车(开笼)。0:暂停</td></tr></table>

# 响应体

代码块

```txt
1 { "code": "10000", "msg": "成功", "data": null } 
```

# 13 getMissionBySubId

POST /openapi-server/slvapi/getMissionBySubId

根据任务id获取任务详情

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>missionSubId</td><td>Integer</td><td></td><td>true</td><td>任务ID</td></tr></table>

# 响应体

代码块

```txt
1 {   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": {   
5 "missionSubId" --任务id   
6 "vin": "vin",   
7 "startStationId": 0,   
8 "startStationName": "起点名称",   
9 "endStationId": 0,   
10 "endStationName": "终点名称"   
11 "missionStatus": 1 // 1.执行中3.已完成，4.已取消   
12 }   
13 }
```

# 接⼝说明

⾳量控制

请求参数(Query Param)  

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

请求体(Request Body)   

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>车辆vin</td></tr><tr><td>volume</td><td>Integer</td><td></td><td>true</td><td>音量，范围：[0,100]</td></tr></table>

# 响应体

代码块

```txt
1 {   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": null   
5 } 
```

# 15 获取任务总⾥程和总时⻓(任务完成后10分钟可调⽤)

POST /openapi-server/slvapi/getMissionMileageAndDurationById

# 接⼝说明

请求参数(Query Param)  

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

请求体(Request Body)   

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>string</td><td></td><td>true</td><td>车辆vin</td></tr><tr><td>missionSubId</td><td>Integer</td><td></td><td>true</td><td>任务id</td></tr></table>

# 响应体

代码块

```json
1 {   
2 "code": "10000",   
3 "msg": "成功",   
4 "data": {   
5 "vin": "LHTBY2B22PY6DA004", --车辆vin   
6 "missionSubId": 5674, --任务id   
7 "mileage": 12321, --任务总里程，单位m，如果未查询到返回-1   
8 "duration": 1, --任务总时长，单位s，如果未查询到返回-1   
9 }   
10 } 
```

# 16批量获取实时基础信息

POST /openapi-server/slvapi/batchGetVehicleList

# 接⼝说明

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td></td><td>签名</td></tr><tr><td>timeStamp</td><td></td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td></td><td>两位随机数</td></tr><tr><td>access_token</td><td></td><td>access_token grasped by / OAuth%/token API</td></tr></table>

# 请求体(Request Body)

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>vin</td><td>List&lt;string&gt;</td><td></td><td>true</td><td>车辆vin</td></tr></table>

# 响应体

```txt
代码块  
1 {  
2 "data":  
3 [  
4 {  
5 "vin":"1",--vin  
6 "vinId":"1",--vinId  
7 "driveMode":1 --驾驶模式1自动驾驶模式2远程脱困模式3近场遥控模式0  
缺省  
8 "gear":"D", --档位  
9 "speed":0.0,--车速km/h  
10 "acceleration_V": 0.0,--[0.20000]车辆行驶纵向加速度，单位：0.01m/s2,offset=-100,表示实  
11 际值[-100..100] 65535表示缺省  
12 "acceleration_H": 0.0,--[0.20000]车辆行驶横向加速度，单位：0.01m/s2,offset=-100,表示实  
13 际值[-100..100] 65535表示缺省  
14 "gnssHead":1.1,--航向角  
15 "position":{--位置信息
```

```json
16 "lon": 116.29435747861862, --经度  
17 "lat": 40.05025582727537 --纬度  
18 },  
19 "vehicleAvailable": 0/1, --0车辆可用1车辆不可用  
20 "realBattery": 10, --真正的电池(即当前使用的电池电量)  
21 "batteryHealth": 12, --电池健康度  
22 "mile": 100.11, --续航里程 Km  
23 "occurTimestamp": 1658396724538, --毫秒级时间戳，  
24 "powerState": true, --是否在线  
25 "parkcode":"01065", ----网格编号  
26 "parkname":"工厂", ----网格名称  
27 "faultStatus": 0, --故障状态 0正常 1异常  
28 "chargingStatus": 0, --充电状态 0未充电 1充电中  
29 "chargingGunStatus": 0, -- 充电枪状态 0充电枪已拔 1 充电枪未拔  
30 "lfPressure": 222.34, -- 左前 胎压  
31 "rfPressure": 222.34, -- 右前 胎压  
32 "lrPressure": 222.34, -- 左后 胎压  
33 "rrPressure": 222.34, -- 右后 胎压  
34 "cabinetStatus": 0 -- 0关闭 1打开  
35 }  
36 ],  
37  
38 "code": "10000",  
39 "msg": "成功"  
40 }
```

# 17 ⻋辆基础信息列表 $( \mathsf { T } + \mathsf { 1 } )$

POST /openapi-server/slvapi/getVehicleBaseList

# 接⼝说明

⻋辆基础信息列表

# 请求参数(Query Param)

<table><tr><td>参数名称</td><td>默认值</td><td>描述</td></tr><tr><td>signature</td><td>李高1723</td><td>签名</td></tr><tr><td>timeStamp</td><td>李高1723</td><td>时间戳，单位为秒</td></tr><tr><td>nonce</td><td>李高1723</td><td>两位随机数</td></tr><tr><td>access_token</td><td>李高1723</td><td>access_token grasped by / OAuth%/token API</td></tr></table>

请求体(Request Body)   

<table><tr><td>参数名称</td><td>数据类型</td><td>默认值</td><td>不为空</td><td>描述</td></tr><tr><td>enterpriseCode</td><td>String</td><td>企业编码</td><td></td><td>业务类型</td></tr></table>

# 响应体

代码块  
```txt
1 {   
2 "data":[   
3 {   
4 "vin":""，--车架号   
5 "vinId":"X33006"，--车辆编号   
6 "vinCode":"新X1311"，--车牌号   
7 "carryingCapacity":100.11，--载重(单位KG)   
8 "batteryAge":24，--24个月   
9 "vehicleAoi":"河北省北京市朝阳区"，--网格名称   
10 "parkCode":"010101"，--网格编码   
11 "cityCode":"--城市编码   
12 "address":"北京市朝阳区恒通商务园" --地址名称   
13 "enduranceMileage":111.45 --车辆满载里程 单位：km   
14 "interspace":6 空间大小 单位m³   
15 "vinType":"X3Pro" -- 车型号   
16 "cabinetNum":3 -- 车门数   
17 }   
18 ],   
19 "code":"10000",   
20 "msg":"成功"   
21 }
```