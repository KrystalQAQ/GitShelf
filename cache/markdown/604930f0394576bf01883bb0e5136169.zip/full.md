# 监控单车页面嵌入

<table><tr><td>日期</td><td>版本</td><td>说明</td><td>作者</td></tr><tr><td>2024/09/19</td><td>1.0</td><td>新增文档</td><td>范亚运</td></tr><tr><td>2024/09/24</td><td>1.1</td><td>增加了多车页面</td><td>范亚运</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></table>

# 目录

目录

目录 2

文档简介 2

1.1 特别声明 2  
1.2 产品说明

接入步骤 3

1.3 Access token 的获取 3  
1.4 页面url生成 5

1.4.1 多车页面 5  
1.4.2 单车页面 5

# 文档简介

# 1.1特别声明

未得到本公司的书面许可，不得为任何目的、以任何形式或手段（包括但不限于机械的或电子的）复制或传播本文档的任何部分。对于本文档涉及的技术和产品，本公司拥有其专利（或正在申请专利）、商标、版权或其它知识产权。除非得到本公司的书面许可协议，本文档不授予这些专利、商标、版权或其它知识产权的许可。

本文档因产品功能示例和描述的需要，所使用的任何人名、企业名和数据都是虚构的，并仅限于本公司内部测试使用，不等于本公司有对任何第三方的承诺和宣传。

# 1.2产品说明

本文档主要描述了如何在已有前端的页面内，以 iframe 的形式嵌入九识提供的

# 接入步骤

# 1.3 Access token 的获取

测试环境URL: https://auth-uat.zelostech.com.cn/oauth-token

线上环境URL：https://auth.zelostech.com.cn/oauth-token

Content-Type: application/x-www-form-urlencoded

请求方式：post

接口备注：该接口由三方服务端去调用，用于根据用户名密码获取 token。

生成的 token 有效期默认是 24 小时,三方需要注意过期后刷新页面的时机,

否则页面在 token 失效后会显示相关失效的错误提示

请求参数说明：  

<table><tr><td>参数名</td><td>示例值</td><td>参数类型</td><td>是否必填</td><td>参数描述</td></tr><tr><td>grant_type</td><td>username_password_authorization_code</td><td>String</td><td>是</td><td>固定值
username_password_authorization_code</td></tr><tr><td>client_id</td><td></td><td>String</td><td>是</td><td>应用的 client_id，九识提供</td></tr><tr><td>client_secret</td><td></td><td>String</td><td>是</td><td>应用的 client_secret，九识提供</td></tr><tr><td>username</td><td></td><td>String</td><td>是</td><td>客户公司下的某个用户名</td></tr><tr><td>password</td><td></td><td>String</td><td>是</td><td>客户公司下的某个用户名对应的密码</td></tr></table>

返回参数说明（以下列出了关键的字段）：  

<table><tr><td>参数名</td><td>示例值</td><td>参数类型</td><td>参数描述</td></tr><tr><td>success</td><td>true</td><td>Boolean</td><td>成功响应</td></tr><tr><td>errorCode</td><td>null</td><td>String</td><td>暂无描述</td></tr><tr><td>message</td><td>null</td><td>String</td><td>暂无描述</td></tr><tr><td>data</td><td></td><td>Object</td><td>返回数据</td></tr><tr><td>data.access_token</td><td>n1x_Od9kYe9SUYnH5M6QrPSEpnUG8BvyG3bkxxk2Xr-YsumMZmijZtREE1FzzL75IA9ZYP056A68YyyJyG1tNp3y2KVidvy_or5gohSffCb-5ams3EJsiHilt5sV0_6d7s</td><td>String</td><td>access_token 值，用于生成嵌入的页面url</td></tr><tr><td>data.user_name</td><td>Colin</td><td>String</td><td>用户名</td></tr><tr><td>data.organization_name</td><td>九识科技</td><td>String</td><td>用户的公司名称</td></tr><tr><td>datails expires_in</td><td>86299</td><td>Integer</td><td>Token 多久后过期，单位 S</td></tr></table>

返回示例：

![](images/386ac91a844febb3d0f96582951d0d636adf9e2ad254d2f2439a7aeb34a367d9.jpg)

```json
"user_type": "USER_TYPE_NORMAL",  
"user_id": 9999999,  
"user_name": "Colin",  
"scope": "all",  
"organization_id": 9999999,  
"organization_type": "THIRD",  
"organization_name": "九识科技",  
"token_type": "Bearer",  
"mobile_number": "18888888888",  
"Expires_in": 86299,  
"email": "xxxxxxxxxx@xxxxxx.com"  
} 
```

# 1.4页面url生成

使用上一步生成的access token，拼接如下的url（注意线上域名不一样），作为ifame的src属性值

# 1.4.1 多车页面

测试环境：https://view-uat.zelostech.com.cn/?accessToken={xxxx}

线上环境：https://view.zelostech.com.cn/?accessToken $\equiv$ {xxxx}

例如：

https://view-uat.zelostech.com.cn/?accessToken=tAm9L3minz3dPs2r_QY3iD4gMrJFOaS7IRQzegKIS ANSely

9Sr0ErMYDKD2PvSKh-e_le2dRdHfOqEGV06D-DOtAWNne-UxhIDZbBSfbgSrRgYNzKRMSFvj5rlbImo0

# 1.4.2 单车页面

测试环境：https://view-uat.zelostech.com.cn/vehicle/{vehicleName}?accessToken $\equiv$ {xxxxx}

线上环境：https://view.zelostech.com.cn/vehicle/{vehicleName}?accessToken $\equiv$ {xxxx}

例如：

https://view-uat.zelostech.com.cn/vehicle/ZL00075?accessToken=tAm9L3minz3dPs2r QY3iD4qMrJFOaS7IR

QzegKIS ANSely9Sr0ErMYDKD2PvSKh-e le2dRdHfOqEGV06D- DOtAWNnE-uXhlDZbBSfbgSrRqYNzKRMSF

vj5rblmo0