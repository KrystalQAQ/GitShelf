# 九识通用推送文档

# V2.11

<table><tr><td>日期</td><td>版本</td><td>说明</td><td>作者</td></tr><tr><td>2023/4/8</td><td>V1.0</td><td>新增文档</td><td>肖伟</td></tr><tr><td>2023/7/4</td><td>V2.0</td><td>增加刹车、油门等字段</td><td>肖伟</td></tr><tr><td>2023/7/9</td><td>V2.1</td><td>业务推送增加上一个停靠点id和name</td><td>肖伟</td></tr><tr><td>2024/8/25</td><td>V2.2</td><td>补充充电状态、车辆模式枚举值</td><td>李鹏飞</td></tr><tr><td>2024/10/8</td><td>v2.3</td><td>补充挡位,方向盘,转向灯等字段</td><td>范亚运</td></tr><tr><td>2024/10/15</td><td>v2.4</td><td>增加胎压</td><td>肖伟</td></tr><tr><td>2024/11/06</td><td>V2.5</td><td>车辆实时数据增加zoeStatus和zoeStatusName</td><td>倪文斌</td></tr><tr><td>2025/03/20</td><td>v2.6</td><td>车辆实时数据新增货箱状态</td><td>肖伟</td></tr><tr><td>2025/05/22</td><td>v2.7</td><td>实时数据新增dispatchId</td><td>李鹏飞</td></tr><tr><td>2025/07/10</td><td>v2.8</td><td>增加冷机温度,货箱温度推送</td><td>肖伟</td></tr><tr><td>2025/08/06</td><td>v2.9</td><td>增加距离下一个点位;增加预期时间和规划距离</td><td>肖伟</td></tr><tr><td>2025/08/26</td><td>v2.10</td><td>新增当前点位序号currentGoallIndex,当前路段序号currentPathIndex</td><td>李鹏飞</td></tr><tr><td>22025/11/20</td><td>v2.11</td><td>1.业务状态推送消息,补充cancelled: true/falsecancelReason:&quot;无法恢复任务&quot;;2.实时消息,补充车辆锁状态doors。</td><td>李鹏飞</td></tr></table>

# 目录

# 目录

1文档简介.. 4

1.1 特别声明. 4   
1.2 阅读对象. 4   
1.3 准备工作. 4

2无人车实时数据推送接口. 4  
3 无人车业务状态推送接口.. 9  
3 附录.. . 11

3.1车辆配送状态. . 11  
3.2 订单状态. . 12   
3.3 车辆模式. . 12  
3.4 充电状态. . 12   
3.5 档位状态. . 13   
3.6 车辆状态. . 13

# 1 文档简介

# 1.1 特别声明

未得到本公司的书面许可，不得为任何目的、以任何形式或手段（包括但不限于机械的或电子的）复制或传播本文档的任何部分。对于本文档涉及的技术和产品，本公司拥有其专利（或正在申请专利）、商标、版权或其它知识产权。除非得到本公司的书面许可协议，本文档不授予这些专利、商标、版权或其它知识产权的许可。

本文档因产品功能示例和描述的需要，所使用的任何人名、企业名和数据都是虚构的，并仅限于本公司内部测试使用，不等于本公司有对任何第三方的承诺和宣传。

# 1.2 阅读对象

贵公司的技术部门的开发、维护及管理人员，应具备以下基本知识：

1. 熟悉 mqtt 相关知识  
2. 了解信息安全的基本概念。  
3. 了解计算机至少一种编程语言。

# 1.3 准备工作

需要企业提供给九识mqtt server 的host，用户名和密码。

九识将提供 topic 中的 organizationCode

# 2 无人车实时数据推送接口

topic：{organizationCode}/vehicle/+/realtime/push

样例：40eabcdef/vehicle/+/realtime/push

接口备注：推送车辆的实时状态信息。

推送条件：车辆开机且正常联网

推送频率：1HZ

数据结构说明：

<table><tr><td>参数名</td><td>示例值</td><td>参数类型</td><td>参数描述</td></tr><tr><td>vehicleName</td><td>ZL00009</td><td>String</td><td>车辆号</td></tr><tr><td>vehicleNumber</td><td>苏ZL0009</td><td>String</td><td>车牌</td></tr><tr><td>vehicleVin</td><td>sdtx3436akdg</td><td>String</td><td>车架号</td></tr><tr><td>lon</td><td>120.414856</td><td>Double</td><td>经度wgs84</td></tr><tr><td>lat</td><td>31.444663</td><td>Double</td><td>纬度wgs84</td></tr><tr><td>gcj02Lat</td><td></td><td>Double</td><td>纬度gcj02，基于火星坐标系，用于高德等地图</td></tr><tr><td>gcj02Lon</td><td></td><td>Double</td><td>经度gcj02</td></tr><tr><td>heading</td><td>-1.4343013932237383</td><td>Number</td><td>朝向，弧度制。正东为0，逆时针为正，顺时针为负。例：1.57为正北，3.14为正西，-1.57为正南，-3.14为正西</td></tr><tr><td>speed</td><td>0</td><td>Integer</td><td>速度单位m/s</td></tr><tr><td>power</td><td>20.8</td><td>Double</td><td>电量%</td></tr><tr><td>temperature</td><td>20.5</td><td>Double</td><td>电池温度℃</td></tr><tr><td>odometer</td><td>82546.362</td><td>Double</td><td>里程计值。单位：米</td></tr><tr><td>globalMileage</td><td>10020.212354</td><td>Double</td><td>当前任务总里程。单位：米</td></tr><tr><td>travelledMileage</td><td>2313.22</td><td>Double</td><td>当前任务已经走过的里程。单位：米</td></tr><tr><td>currentToTargetMileage</td><td>1500</td><td>Double</td><td>距离下一个停靠点的距离。单位：米</td></tr><tr><td>currentGoallIndex</td><td>1</td><td>Integer</td><td>当前点位序号</td></tr><tr><td>currentPathIndex</td><td>0</td><td>Integer</td><td>当前路段序号</td></tr><tr><td>chassisState</td><td>DRIVEMODE.TakeOVER_EMERGENCY_STOP</td><td>String</td><td>车辆模式</td></tr><tr><td>chassisSTATEName</td><td>按钮急停</td><td>String</td><td>chassisState翻译</td></tr><tr><td>vehicleState</td><td>NORMAL</td><td>String</td><td>车辆状态</td></tr><tr><td>vehicleSTATEName</td><td>正常</td><td>String</td><td>车辆状态翻译</td></tr><tr><td>vehicleBusinessStatus</td><td>ONWAY</td><td>String</td><td>配送状态</td></tr><tr><td>vehicleBusinessStatusName</td><td>去程</td><td>String</td><td>配送状态名称。附录3.1</td></tr><tr><td>dispatchId</td><td>1508</td><td>Long</td><td>九识的任务编号</td></tr><tr><td>chargeStatus</td><td>CHARGING</td><td>String</td><td>充电状态</td></tr><tr><td>chargeStatusName</td><td>充电中</td><td>String</td><td>充电状态</td></tr><tr><td>throttle</td><td>2</td><td>Double</td><td>油门</td></tr><tr><td>brake</td><td>1</td><td>Double</td><td>刹车</td></tr><tr><td>frontLowLight</td><td>true</td><td>boolean</td><td>近光灯是否亮</td></tr><tr><td>frontHightLight</td><td>true</td><td>boolean</td><td>远光灯是否亮</td></tr><tr><td>brakeLight</td><td>true</td><td>boolean</td><td>刹车灯是否亮</td></tr><tr><td>backLight</td><td>true</td><td>boolean</td><td>倒车灯是否亮</td></tr><tr><td>timestamp</td><td>1687161562000</td><td>Integer</td><td>上报时间</td></tr><tr><td>gear</td><td>GEAR PARKING</td><td>String</td><td>档位编码</td></tr><tr><td>gearName</td><td>驻车</td><td>String</td><td>档位名称</td></tr><tr><td>frontWheelAngle</td><td>-0.2617993877</td><td>Double</td><td>方向盘转向角度，正数向左，负数向右，单位弧度，α（度）=α（弧度）×180°/π</td></tr><tr><td>leftLight</td><td>false</td><td>boolean</td><td>左转向灯打开状态</td></tr><tr><td>rightLight</td><td>false</td><td>boolean</td><td>右转向灯打开状态</td></tr><tr><td>hazardLight</td><td>true</td><td>boolean</td><td>双闪是否打开，打开的情况忽略 leftLight 和 rightLight</td></tr><tr><td>wheelStatus</td><td></td><td>List</td><td>轮胎列表</td></tr><tr><td>wheelStatus.wheelPosition</td><td></td><td>String</td><td>轮胎位置。WHEEL POSITION_FRONT_L EFT WHEEL POSITION_FRONT_RIGHT WHEEL POSITION_FRONT_RIGHT WHEEL POSITION_FRONT_RIGHT WHEEL POSITION_FRONT_RIGHT</td></tr><tr><td>wheelStatuspressure</td><td></td><td>Integer</td><td>胎压值</td></tr><tr><td>zoeStatus</td><td>ZOE STARTED</td><td>String</td><td>启动状态码</td></tr><tr><td>zoeStatusName</td><td>启动成功</td><td>String</td><td>启动状态值</td></tr><tr><td>doorStatus</td><td>{"3":"DOOR_CLOSE","4":"DOOR_CLOSE"}</td><td>Map</td><td>货箱状态。DOOR_CLOSE 关闭 DOOR_OPEN 开启</td></tr><tr><td>doors</td><td>[{"doorNo":1,"doorSta tus":"DOOR_CLOSE","lo cks":"lockNo":3,"lo</td><td>Array</td><td>货箱门以及对应锁状态 LOCK_UNLOCK 未落锁 LOCK_LOCKED 已落锁</td></tr><tr><td></td><td>ckStatus":"LOCK_UNLOC K"}}], {"doorNo":2, "do orStatus":"DOOR_CLOSE ", "locks":"\{"lockNo": 4, "lockStatus":"LOCK_ UNLOCK"\}]}}</td><td></td><td></td></tr><tr><td>coolingMachineTemperatur e</td><td>30</td><td>Double</td><td>冷机温度(非冷链车为 null)</td></tr><tr><td>boxFrontAreaTemperature</td><td>25.8</td><td>Double</td><td>货箱前部温度(非冷链车为 null)</td></tr><tr><td>boxBackAreaTemperature</td><td>26.4</td><td>Double</td><td>货箱后部温度(非冷链车为 null)</td></tr></table>

消息体示例：

```javascript
"vehicleName":"ZL00009",//车辆号
"lon":120.414856, // 经度 wgs84
"lat":31.444663, // 纬度 wgs84
"gcj02Lon":120.414856, // 经度 gcj02
"gcj02Lat":31.444663, // 纬度 gcj02
"heading":-1.4343013932237383, // 朝向，弧度制。正东为0，逆时针为正，顺时针为付。例：1.57为正北，3.14为正西，-1.57为正南，-3.14为正西
"speed":0.0, // 速度单位 m/s
"power":20.8, // 电量%
"chassisState":"DRIVEMODE.TakeOVER_EMERGENCY_STOP", // 车辆模式
"chassisStateName":"按钮急停",
"vehicleState":"NORMAL", // 车辆状态
"vehicleStateName":"正常",
"vehicleBusinessStatus":"ONWAY", // 配送状态
"vehicleBusinessStatusName":"去程",
"timestamp":1687161562000 // 上报时间，
```

```javascript
"gear":"GEAR PARKING", "gearName":"驻车", "frontWheelAngle":3.390983261952836e-17, "leftLight":false, "rightLight":false, "hazardLight":false, "wheelStatus":"wheelPosition":"WHEEL POSITION_FRONT_LEFT","pressure":306},{"wheelPosi tion":"WHEEL POSITION_FRONT_RIGHT","pressure":311},{"wheelPosition":"WHEEL POSITIONBack_LEFT","pressure":318},{"wheelPosition":"WHEEL POSITION.Back_RIGHT","pressure":321 }},"zoeStatus":"ZOE_started","zoeStatusName":"启动成功", "doorStatus":"3":"DOOR_CLOSE","4":"DOOR_CLOSE"},"doors":[ { "doorNo":1, "doorStatus":"DOOR_CLOSE", "locks":[ { "lockNo":3, "lockStatus":"LOCK_UNLOCK" } ] } } { "doorNo":2, "doorStatus":"DOOR_CLOSE", "locks":[ { "lockNo":4, "lockStatus":"LOCK_UNLOCK" } ] } 
```

# 3 无人车业务状态推送接口

topic：{organizationCode}/vehicle/+/business/push

样例：04abcdefg/vehicle/+/business/push

接口备注：推送车辆的业务状态

推送条件：车辆的业务状态发生变化的时候，推送一次

数据结构说明：

<table><tr><td>参数名</td><td>示例值</td><td>参数类型</td><td>参数描述</td></tr><tr><td>vehicleName</td><td>ZL00009</td><td>String</td><td>车辆号</td></tr><tr><td>vehicleBusinessStatus</td><td>ONWAY</td><td>String</td><td>配送状态.附录3.1</td></tr><tr><td>vehicleBusinessStatusName</td><td>去程</td><td>String</td><td>配送状态名称</td></tr><tr><td>cancelled</td><td>true</td><td>Boolean</td><td>是否主动取消导致的配送状态空闲，true表示取消导致，false表示任务正常完成</td></tr><tr><td>cancelUser</td><td>张三</td><td>String</td><td>取消任务的用户信息</td></tr><tr><td>timestamp</td><td>1687161562000</td><td>Integer</td><td>上报时间</td></tr><tr><td>currentGoallIndex</td><td>1</td><td>Integer</td><td>车辆任务当前目的地Index，0表示还未触发，1表示去往第一个停靠点或者已经到第一个达停靠点，可结合车辆业务状态和点位列表来判断</td></tr><tr><td>currentStopId</td><td>1</td><td>Integer</td><td>当前前往(停靠)停靠点id。如果是去程或者返程，则表示前往的点。如果是投递中，表示当前停留等待的点位。</td></tr><tr><td>currentStopName</td><td>红新校区</td><td>String</td><td>前往(停靠)停靠名称</td></tr><tr><td>lastStopId</td><td>2</td><td>Integer</td><td>上一个停靠点ID</td></tr><tr><td>lastStopName</td><td>东风路口</td><td>String</td><td>上一个停靠点名称</td></tr><tr><td>currMileages</td><td>1300</td><td>Double</td><td>当前停靠点的规划里程。单位:米</td></tr><tr><td>currPlanElapsedTime</td><td>35.2</td><td>Double</td><td>此路段预计耗时。单位:分钟。根据最近5天的历史数据预估。</td></tr><tr><td>currPlanAvgSpeed</td><td>6.3</td><td>Double</td><td>最近5天历史任务中当前路段的平均速度。单位:米/秒</td></tr><tr><td>dispatchId</td><td>1508</td><td>Long</td><td>九识的任务编号</td></tr><tr><td>orderList</td><td></td><td>Array</td><td>订单列表。使用九识小程序/app进行业务才会推送这个数据</td></tr><tr><td>orderList.id</td><td></td><td>Integer</td><td></td></tr><tr><td>orderList.orderNo</td><td>202311201236548</td><td>String</td><td>九识内部订单编号</td></tr><tr><td>orderList-originalNo</td><td></td><td>String</td><td>客户订单编号。若无,同orderNo</td></tr><tr><td>orderList(contact</td><td>13512547858</td><td>String</td><td>取货人手机号</td></tr><tr><td>orderList.name</td><td>张三</td><td>String</td><td>取货人姓名</td></tr><tr><td>orderList.stopName</td><td>小区南门</td><td>String</td><td>订单取货点名称</td></tr><tr><td>orderList.stopId</td><td>156</td><td>Integer</td><td>订单取货点id,唯一值</td></tr><tr><td>orderList.gridNo</td><td>1,2,3</td><td>String</td><td>订单放的箱门。可以是一个也可以是多个</td></tr><tr><td>orderList取证Code</td><td>125489</td><td>String</td><td>订单6位验证码</td></tr><tr><td>orderList.orderStatus</td><td>PICKED</td><td>String</td><td>订单状态编码</td></tr><tr><td>orderList.orderStatusName</td><td>已取</td><td>String</td><td>订单状态名称。参考附录3.2</td></tr></table>

请求示例：

![](images/30ad3004e9b5b9bf11a31c1174e6ac4c0f94f2eb7d63ad937c3c62cf827dc3d5.jpg)

```javascript
"currentStopName":"红新校区",//前往(停靠）停靠名称   
"dispatchld":1506,   
"orderList":[ { "id":171, "orderNo":"20231103170110483", "originalNo":"20231103170110483", "orderStatus":"PICKED", "orderStatusName":"已取", "contact":"15726608952", "name":"chenzhen", "stopId":2238, "stopName":"测试11", "gridNo":"1,2,4", "verifyCode":"849201" } 1 
```

# 3 附录

# 3.1 车辆配送状态

<table><tr><td>状态码</td><td>描述</td></tr><tr><td>IDLE</td><td>车辆空闲状态</td></tr><tr><td>WITHHORDERS</td><td>车辆已经分配了订单或者已经装上了货物</td></tr><tr><td>ROUTING</td><td>车辆正在路径规划中</td></tr><tr><td>ONWAY</td><td>车辆在前往某个取货点的路上</td></tr><tr><td>ATSTOP</td><td>车辆停在某个取货点等待用户（从其他状态切成 ATSTOP 表示车辆到达）</td></tr><tr><td>BACK</td><td>车辆在回装货点的路上</td></tr><tr><td>ARRIVEHOME</td><td>车辆已经到达了最初的装货点，因为车上有货没被取走，导致车辆状态不能自动恢复到IDLE</td></tr></table>

# 3.2 订单状态

<table><tr><td>状态码</td><td>描述</td></tr><tr><td>ONVEHICLE</td><td>已经被装上了车</td></tr><tr><td>ONWAY</td><td>车辆正在前往该订单所属停靠点</td></tr><tr><td>SENTWAITPICK</td><td>已经在车辆距离取货点N米的时候，提前通知了客户准备取货</td></tr><tr><td>WAITPICK</td><td>车辆正停靠在此订单所属取货点，等待用户来取</td></tr><tr><td>PICKED</td><td>这个订单已经被用户取走了</td></tr><tr><td>MISSICK</td><td>车辆已经离开了此订单取货点，订单没有被取走</td></tr><tr><td>TASKCANCELLED</td><td>订单所属的车辆任务被取消了</td></tr></table>

# 3.3 车辆模式

<table><tr><td>车辆模式</td><td>描述</td></tr><tr><td>DRIVEMODE_UNKNOWN</td><td>初始化</td></tr><tr><td>DRIVEMODE_ENGAGED_INIT</td><td>车辆待机</td></tr><tr><td>DRIVEMODE_ENGAGED_AUTO_CTRL</td><td>自动驾驶</td></tr><tr><td>DRIVEMODE.TakeOVER remotCTRL</td><td>平台控制</td></tr><tr><td>DRIVEMODE_ENGAGED_VANGUARD_EMERGENCY</td><td>紧急制动</td></tr><tr><td>DRIVEMODE_ENGAGED_VANGUARD_FORBID_DRIVING</td><td>中止驾驶</td></tr><tr><td>DRIVEMODE.TakeOVER remotSUPER_CTRL</td><td>强制遥控</td></tr><tr><td>DRIVEMODE_ENGAGED_CHASSIS_STANDBY</td><td>底盘待机</td></tr><tr><td>DRIVEMODE.TakeOVER_CHASSIS_CTRL</td><td>手柄控制</td></tr><tr><td>DRIVEMODE_ENGAGED_CHASSIS_BUMPER</td><td>碰撞停车</td></tr><tr><td>DRIVEMODE_ENGAGED_CHASSIS_FAULT</td><td>底盘故障</td></tr><tr><td>DRIVEMODE.TakeOVER_EMERGENCY_STOP</td><td>按钮急停</td></tr><tr><td>DRIVEMODE_ENGAGED_VANGUARD_NORMAL</td><td>异常保护</td></tr></table>

# 3.4 充电状态

<table><tr><td>状态码</td><td>描述</td></tr><tr><td>DISCHARGE</td><td>未充电</td></tr><tr><td>CHARGING</td><td>充电中</td></tr><tr><td>CHARGED</td><td>已充满</td></tr></table>

# 3.5 档位状态

<table><tr><td>状态码</td><td>描述</td></tr><tr><td>GEAR_NEUTRAL</td><td>空档</td></tr><tr><td>GEAR_DRIVE</td><td>前进</td></tr><tr><td>GEAR_REVERSE</td><td>倒车</td></tr><tr><td>GEAR_PARKING</td><td>驻车</td></tr></table>

# 3.6车辆状态

<table><tr><td>状态码</td><td>描述</td></tr><tr><td>NORMAL</td><td>正常</td></tr><tr><td>SELF_REPAIR</td><td>自我修复</td></tr><tr><td>OFFLINE</td><td>离线</td></tr><tr><td>MALFUNCTION</td><td>故障</td></tr></table>